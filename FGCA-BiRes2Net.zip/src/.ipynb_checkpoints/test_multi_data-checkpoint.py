import math
import numpy as np
import time
import torchvision.models as models
import torch.utils.data as data
from torchvision import transforms
import cv2
import pandas as pd
import os ,torch
import torch.nn as nn
import image_utils
import argparse,random
import office_res2net


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--raf_path', type=str, default='/home/featurize/data/raf-basic+/', help='Raf-DB dataset path.')
    parser.add_argument('--checkpoint', type=str, default="/home/featurize/work/Self-Cure-Network-master/src/models/1203_train-v1-res2net18-1st[1,1,1,2]/epoch31_acc0.7787.pth",
                        help='Pytorch checkpoint file path')
    # 模型存储路径
    # "src/models/1201-bs-64-epo-70-base/epoch67_acc0.8432.pth"#修改为你自己保存下来的模型文件
    # "F:/projects/1202_Self-Cure-Network-master/src/models/epoch1_acc0.6776.pth"  # 修改为你自己保存下来的模型文件
    # "pre_model/state-of-the-art models/ijba_res18_naive.pth.tar"
    parser.add_argument('--batch_size', type=int, default=128, help='Batch size.')
    parser.add_argument('--workers', default=0, type=int, help='Number of data loading workers (default: 0)')
    return parser.parse_args()


class Res18Feature(nn.Module):
    def __init__(self, pretrained, num_classes=7):
        super(Res18Feature, self).__init__()
        # resnet = models.resnet18(pretrained)
        resnet = office_res2net.res2net18(pretrained)
        # self.feature = nn.Sequential(*list(resnet.children())[:-2]) # before avgpool
        self.features = nn.Sequential(*list(resnet.children())[:-1])  # after avgpool 512x1

        fc_in_dim = list(resnet.children())[-1].in_features  # original fc layer's in dimention 512

        self.fc = nn.Linear(fc_in_dim, num_classes)  # new fc layer 512x7
        self.alpha = nn.Sequential(nn.Linear(fc_in_dim, 1), nn.Sigmoid())

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)

        out = self.fc(x)
        return out

class RafDataSet(data.Dataset):
    def __init__(self, raf_path, phase, transform=None, basic_aug=False):
        self.phase = phase
        self.transform = transform
        self.raf_path = raf_path

        NAME_COLUMN = 0
        LABEL_COLUMN = 1
        df = pd.read_csv(os.path.join(self.raf_path, 'EmoLabel/list_patition_label.txt'), sep=' ', header=None)
        if phase == 'train':
            dataset = df[df[NAME_COLUMN].str.startswith('train')]
        else:
            dataset = df[df[NAME_COLUMN].str.startswith('test')]
        file_names = dataset.iloc[:, NAME_COLUMN].values
        self.label = dataset.iloc[:,
                     LABEL_COLUMN].values - 1  # 0:Surprise, 1:Fear, 2:Disgust, 3:Happiness, 4:Sadness, 5:Anger, 6:Neutral

        self.file_paths = []
        # use raf aligned images for training/testing
        for f in file_names:
            f = f.split(".")[0]
            f = f + "_aligned.jpg"
            path = os.path.join(self.raf_path, 'Image/aligned', f)
            self.file_paths.append(path)

        self.basic_aug = basic_aug
        self.aug_func = [image_utils.flip_image, image_utils.add_gaussian_noise]

    def __len__(self):
        return len(self.file_paths)

    def __getitem__(self, idx):
        path = self.file_paths[idx]
        image = cv2.imread(path)
        image = image[:, :, ::-1]  # BGR to RGB
        label = self.label[idx]
        # augmentation
        if self.phase == 'train':
            if self.basic_aug and random.uniform(0, 1) > 0.5:
                index = random.randint(0, 1)
                image = self.aug_func[index](image)

        if self.transform is not None:
            image = self.transform(image)

        return image, label, idx


def initialize_weight_goog(m, n=''):
    if isinstance(m, nn.Conv2d):
        fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
        m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
        if m.bias is not None:
            m.bias.data.zero_()
    elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1.0)
        m.bias.data.zero_()
    elif isinstance(m, nn.Linear):
        fan_out = m.weight.size(0)  # fan-out
        fan_in = 0
        if 'routing_fn' in n:
            fan_in = m.weight.size(1)
        init_range = 1.0 / math.sqrt(fan_in + fan_out)
        m.weight.data.uniform_(-init_range, init_range)
        m.bias.data.zero_()


def run_test():

    args = parse_args()
    imagenet_pretrained = True
    res18 = Res18Feature(pretrained = imagenet_pretrained)
    if not imagenet_pretrained:
         for m in res18.modules():
            initialize_weight_goog(m)
            
            
    checkpoint = torch.load(args.checkpoint)
    res18.load_state_dict(checkpoint, False)


    data_transforms_val = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])])
    val_dataset = RafDataSet(args.raf_path, phase='test', transform=data_transforms_val)
    print('Validation set size:', val_dataset.__len__())

    val_loader = torch.utils.data.DataLoader(val_dataset,
                                             batch_size=args.batch_size,
                                             num_workers=args.workers,
                                             shuffle=False,
                                             pin_memory=True)


    with torch.no_grad():
        bingo_cnt = 0
        sample_cnt = 0
        res18.cuda()
        res18.eval()

        time1 = time.time()
        for batch_i, (imgs, targets, _) in enumerate(val_loader):
            outputs = res18(imgs.cuda())
            targets = targets.cuda()
            _, predicts = torch.max(outputs, 1)
            correct_num = torch.eq(predicts, targets)
            bingo_cnt += correct_num.sum().cpu()
            sample_cnt += outputs.size(0)

        acc = bingo_cnt.float() / float(sample_cnt)
        acc = np.around(acc.numpy(), 4)
        time2 = time.time()
        print("Test accuracy:%.4f " % (acc))
        print((time2 - time1) * 1000)


if __name__ == "__main__":
    run_test()